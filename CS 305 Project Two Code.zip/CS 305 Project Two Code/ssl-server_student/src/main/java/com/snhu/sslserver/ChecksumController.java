package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChecksumController {
	
	@GetMapping("/hash")
	public String getChecksum() {
		String data = "Damian Duross!";
		
		String checksum = generateChecksum(data);
		
		return "Data: " + data + " | SHA-256 Checksum (Hex): " + checksum;
	}
	
	public String generateChecksum(String data) {
		try {
			
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			
			byte[] hashBytes = digest.digest(data.getBytes());
			
			return bytesToHex(hashBytes);	
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("Error generating checksum", e);
		}
	}
	
	private String bytesToHex(byte[] bytes) {
		StringBuilder hexString = new StringBuilder();
		for (byte b : bytes) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		return hexString.toString();
	}
}
